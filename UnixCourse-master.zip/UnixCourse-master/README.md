This is the Unix Course a took while being a student at ODU. Here is my solutions to the assignments, I used the terminal to help gain familiarity with Linux based environment
