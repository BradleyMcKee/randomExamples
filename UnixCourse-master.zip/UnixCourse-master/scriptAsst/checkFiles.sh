
#!/bin/sh
for i in "$@" ; do
printf "$i: "; ./fileType.sh "$i"
done

case no in
    
#!/bin/sh
for i in "$@" ; do
printf "$i: "; ./fileType.sh "$i"
done


