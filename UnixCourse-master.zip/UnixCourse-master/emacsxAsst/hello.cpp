#include <iostream>

using namespace std;

/*
 * Hello, world program in C++
 */

int main(int argc, char** argv) 
{
  cout << "Hello, world!" << endl;
  return 0;
}
